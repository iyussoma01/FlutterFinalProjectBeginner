import 'package:flutter/material.dart';
import 'package:final_project_iyus/second_page.dart';

class FirstPage extends StatelessWidget {
  final String message = 'JENIS PENJAMINAN ASURANSI KENDARAAN';
  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    Orientation orientation = MediaQuery.of(context).orientation;

    return Scaffold(
      appBar: AppBar(
        title: const Text('ASURANSI KENDARAAN BERMOTOR'),
      ),
      body: SafeArea(
        child: SingleChildScrollView(
            child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Container(
              padding: const EdgeInsets.all(5.0),
              child: Image.network(
                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSIqRXAxY8jMKY3teiUegvV9Lg-wD4fhS9z1g&usqp=CAU',
                width: 200,
                height: 200,
              ),
            ),
            Container(
              padding: const EdgeInsets.all(5.0),
              child: Image.network(
                'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRBoK-VwbJf1c4T8jwLlOYMGbISLyEZju9DIQ&usqp=CAU',
                width: 200,
                height: 150,
              ),
            ),
            Container(
              padding: const EdgeInsets.all(10.0),
              child: const Text(
                'Sekarang tidak perlu khawatir lagi dengan resiko terhadap kendaraan Anda. Asuransi kendaraan bermotor dapat memberikan manfaat perlindungan, kerusakan sampai kehilangan unit kendaraan Anda.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 24.0, fontFamily: 'Oxygen'),
              ),
            ),
            Container(
              padding: const EdgeInsets.all(15.0),
              child: ElevatedButton(
                child: const Text('Klik => Pilihan Manfaat Asuransi Kendaraan'),
                onPressed: () {
                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => SecondPage(message)));
                },
              ),
            ),
          ],
        )),
      ),
    );
  }
}
