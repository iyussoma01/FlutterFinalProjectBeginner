import 'package:flutter/material.dart';

class ThirdPage extends StatefulWidget {
  const ThirdPage({Key? key}) : super(key: key);

  @override
  State<ThirdPage> createState() => _ThirdPageState();
}

class _ThirdPageState extends State<ThirdPage> {
  String _name = '';
  String _email = '';
  String _phone = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(''),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              decoration: const InputDecoration(
                hintText: 'Ketikkan nama Anda...',
                labelText: 'Nama',
              ),
              onChanged: (String value) {
                setState(() {
                  _name = value;
                });
              },
            ),
            TextField(
              decoration: const InputDecoration(
                hintText: 'Ketikkan alamat Email Anda...',
                labelText: 'Email',
              ),
              onChanged: (String value) {
                setState(() {
                  _email = value;
                });
              },
            ),
            TextField(
              decoration: const InputDecoration(
                hintText: 'Ketikkan Nomor telepon Anda...',
                labelText: 'Nomor Telepon',
              ),
              onChanged: (String value) {
                setState(() {
                  _phone = value;
                });
              },
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              child: const Text('Kirim'),
              onPressed: () {
                showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        content: Text(
                            'Halo Bapak/Ibu, $_name, marketing agen kami akan segera menghubungi Anda di alamat email $_email, dan di nomor telepon $_phone. Mohon kesediaan menunggu prosesnya.'),
                      );
                    });
              },
            )
          ],
        ),
      ),
    );
  }
}
