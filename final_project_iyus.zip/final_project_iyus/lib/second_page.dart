import 'package:flutter/material.dart';
import 'package:final_project_iyus/third_page.dart';

class SecondPage extends StatelessWidget {
  final String message;

  const SecondPage(this.message, {Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Size screenSize = MediaQuery.of(context).size;
    Orientation orientation = MediaQuery.of(context).orientation;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Manfaat Produk'),
      ),
      body: Center(
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                message,
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 18.0, fontFamily: 'Arial Black'),
              ),
              Container(
                padding: const EdgeInsets.all(16.0),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: <Widget>[
                    Column(
                      children: const <Widget>[
                        Icon(Icons.car_crash),
                        Text('Kerusakan')
                      ],
                    ),
                    Column(
                      children: const <Widget>[
                        Icon(Icons.car_repair),
                        Text('Bengkel')
                      ],
                    ),
                    Column(
                      children: const <Widget>[
                        Icon(Icons.contact_phone),
                        Text('Laporan Klaim 24 Jam'),
                      ],
                    )
                  ],
                ),
              ),
              SizedBox(
                height: 400,
                child: ListView(
                  scrollDirection: Axis.vertical,
                  children: <Widget>[
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Text(
                          'COMPREHENSIVE',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 20, fontFamily: 'Oswald'),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset('images/comprehensive.png'),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Text(
                          'TOTAL LOST ONLY',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 20, fontFamily: 'Oswald'),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.all(4.0),
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: Image.asset('images/tlo.jpg'),
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(5.0),
                child: ElevatedButton(
                  child: const Text('Tertarik Dihubungi'),
                  onPressed: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => ThirdPage()));
                  },
                ),
              ),
              Container(
                padding: const EdgeInsets.all(5.0),
                child: ElevatedButton(
                  child: const Text('Kembali'),
                  onPressed: () {
                    Navigator.pop(context);
                  },
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
