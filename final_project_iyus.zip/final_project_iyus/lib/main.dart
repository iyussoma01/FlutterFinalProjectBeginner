import 'package:flutter/material.dart';
import 'package:final_project_iyus/first_page.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        fontFamily: 'Calibri',
        primarySwatch: Colors.deepPurple,
      ),
      home: FirstPage(), // Panggil FirstScreen di sini
    );
  }
}
